# Muslim Life – Combined Starter App

This single ZIP combines the original starter features with automatic prayer-time calculation, Sunrise and approximate Ishraq display, plus Tahajjud reminder and an approximate last-third-of-night estimate.

Included:
- English, Hindi, Urdu and Arabic interface labels
- Prayer times: automatic by device location or city/country; calculation method selector; manual prayer-time editing
- Next prayer countdown
- Sunrise and approximate Ishraq time (shown 15 minutes after calculated sunrise)
- Jamaat time settings
- Tahajjud reminder time and approximate start of the last third of the night
- Digital Tasbih
- Ramadan Suhoor and Iftar manual times/countdowns
- Qibla bearing helper
- Quran.com link
- Basic offline app-shell caching

Important limitations:
- Prayer times need internet for fresh calculations and must be verified with the local mosque.
- Ishraq is a voluntary prayer; its display is an approximation after sunrise. Follow local scholarly guidance.
- Tahajjud last-third calculation is approximate; confirm locally.
- Browser notifications and reminders may not work when the app is closed or the phone is asleep. This is a PWA prototype, not a native Android app or a certified prayer timetable.
- Quran text/audio is not bundled; the Quran section links to Quran.com.
- Ramadan times and Jamaat times are user-entered.
- Host on HTTPS (for example Netlify) for location and service worker support.
