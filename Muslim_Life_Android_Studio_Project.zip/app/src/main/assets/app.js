const $=id=>document.getElementById(id);
const prayers=["Fajr","Dhuhr","Asr","Maghrib","Isha"];
const defaults={Fajr:"05:00",Dhuhr:"12:15",Asr:"15:30",Maghrib:"18:00",Isha:"19:30"};
const get=(k,d)=>{try{return JSON.parse(localStorage.getItem(k))??d}catch{return d}};
const put=(k,v)=>localStorage.setItem(k,JSON.stringify(v));
let prayerTimes=get("prayerTimes",defaults),jamaatTimes=get("jamaatTimes",{}),tasbih=get("tasbih",0),ramadan=get("ramadan",{suhoor:"04:30",iftar:"18:00"});
function inputs(container,values,prefix){$(container).innerHTML=prayers.map(p=>`<label>${p}<input type="time" id="${prefix}${p}" value="${values[p]||""}"></label>`).join("")}
inputs("prayerInputs",prayerTimes,"p");inputs("jamaatInputs",jamaatTimes,"j");
function collect(prefix){return Object.fromEntries(prayers.map(p=>[p,$(prefix+p).value]))}
$("savePrayer").onclick=()=>{prayerTimes=collect("p");put("prayerTimes",prayerTimes);alert("Prayer times saved on this device.")};
$("saveJamaat").onclick=()=>{jamaatTimes=collect("j");put("jamaatTimes",jamaatTimes);alert("Jamaat times saved on this device.")};
function nextAt(time){let [h,m]=time.split(":").map(Number),d=new Date();d.setHours(h,m,0,0);if(d<=new Date())d.setDate(d.getDate()+1);return d}
function fmt(ms){if(ms<0)ms=0;let s=Math.floor(ms/1000);return [Math.floor(s/3600),Math.floor(s%3600/60),s%60].map(x=>String(x).padStart(2,"0")).join(":")}
function tick(){let now=new Date(),upcoming=prayers.map(p=>({p,t:nextAt(prayerTimes[p]||"00:00")})).sort((a,b)=>a.t-b.t)[0];$("nextPrayer").textContent=upcoming.p;$("nextTime").textContent=upcoming.t.toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"});$("nextCountdown").textContent=fmt(upcoming.t-now);
for(const [key,id] of [["suhoor","suhoorCount"],["iftar","iftarCount"]]){let v=$(key).value||ramadan[key];if(v){let t=nextAt(v);$(id).textContent=fmt(t-now)}}
}
setInterval(tick,1000);tick();
document.querySelectorAll("[data-page]").forEach(b=>b.addEventListener("click",()=>{document.querySelectorAll(".page").forEach(x=>x.hidden=true);let p=$("page-"+b.dataset.page);if(p)p.hidden=false;window.scrollTo({top:p?.offsetTop-70||0,behavior:"smooth"})}));
document.querySelectorAll("[data-home]").forEach(b=>b.onclick=()=>{document.querySelectorAll(".page").forEach(x=>x.hidden=true);window.scrollTo({top:0,behavior:"smooth"})});
$("countBtn").onclick=()=>{$("tasbihCount").textContent=++tasbih;put("tasbih",tasbih)};$("tasbihCount").textContent=tasbih;
$("resetCount").onclick=()=>{tasbih=0;$("tasbihCount").textContent=0;put("tasbih",0)};
$("dhikrSelect").onchange=e=>$("dhikrText").textContent=e.target.value;
$("suhoor").value=ramadan.suhoor;$("iftar").value=ramadan.iftar;
$("saveRamadan").onclick=()=>{ramadan={suhoor:$("suhoor").value,iftar:$("iftar").value};put("ramadan",ramadan);tick();alert("Ramadan times saved on this device.")};
$("tahajjudTime").value=get("tahajjudTime","03:30");
$("saveTahajjud").onclick=async()=>{let t=$("tahajjudTime").value;put("tahajjudTime",t);if("Notification"in window&&Notification.permission==="default")await Notification.requestPermission();$("tahajjudStatus").textContent="Reminder time saved: "+t+". Keep app open; background alarms are not guaranteed.";};
let lastTahajjudNotice="";
setInterval(()=>{const t=get("tahajjudTime","");if(!t)return;const now=new Date(),key=now.toDateString()+t;if(now.toTimeString().slice(0,5)===t&&lastTahajjudNotice!==key){lastTahajjudNotice=key;if("Notification"in window&&Notification.permission==="granted")new Notification("Muslim Life",{body:"Tahajjud reminder"});}},15000);
$("gregDate").textContent=new Date().toLocaleDateString(undefined,{dateStyle:"full"});
$("qiblaBtn").onclick=()=>{if(!navigator.geolocation){$("qiblaResult").textContent="Location unavailable";return}navigator.geolocation.getCurrentPosition(pos=>{let lat=pos.coords.latitude*Math.PI/180,lon=pos.coords.longitude*Math.PI/180,kaabaLat=21.4225*Math.PI/180,kaabaLon=39.8262*Math.PI/180;let y=Math.sin(kaabaLon-lon),x=Math.cos(lat)*Math.tan(kaabaLat)-Math.sin(lat)*Math.cos(kaabaLon-lon);let deg=(Math.atan2(y,x)*180/Math.PI+360)%360;$("qiblaResult").textContent=Math.round(deg)+"° from North";},()=>{$("qiblaResult").textContent="Location permission denied"})};
const translations={hi:{welcome:"अस्सलामु अलैकुम",nextLabel:"अगली नमाज़",tPrayer:"नमाज़ और अज़ान",tJamaat:"जमात",tQuran:"कुरान शरीफ",tTasbih:"डिजिटल तस्बीह",tRamadan:"रमज़ान",tTahajjud:"तहज्जुद",tQibla:"किबला कम्पास",tCalendar:"इस्लामिक कैलेंडर"},ur:{welcome:"السلام علیکم",nextLabel:"اگلی نماز",tPrayer:"نماز اور اذان",tJamaat:"جماعت",tQuran:"قرآن شریف",tTasbih:"ڈیجیٹل تسبیح",tRamadan:"رمضان",tTahajjud:"تہجد",tQibla:"قبلہ",tCalendar:"اسلامی کیلنڈر"},ar:{welcome:"السلام عليكم",nextLabel:"الصلاة القادمة",tPrayer:"الصلاة والأذان",tJamaat:"الجماعة",tQuran:"القرآن الكريم",tTasbih:"السبحة الرقمية",tRamadan:"رمضان",tTahajjud:"قيام الليل",tQibla:"القبلة",tCalendar:"التقويم الهجري"}};
$("language").onchange=e=>{let t=translations[e.target.value]||{};for(let id in t)if($(id))$(id).textContent=t[id];document.documentElement.dir=["ar","ur"].includes(e.target.value)?"rtl":"ltr";};

// Automatic prayer-time calculation, sunrise and Ishraq
const timeOnly=s=>{const m=String(s||"").match(/(\d{1,2}):(\d{2})/);return m?`${m[1].padStart(2,"0")}:${m[2]}`:""};
function displayCalculated(data,label){
  const t=data.timings;
  prayerTimes={Fajr:timeOnly(t.Fajr),Dhuhr:timeOnly(t.Dhuhr),Asr:timeOnly(t.Asr),Maghrib:timeOnly(t.Maghrib),Isha:timeOnly(t.Isha)};
  put("prayerTimes",prayerTimes);
  inputs("prayerInputs",prayerTimes,"p");
  const sunrise= timeOnly(t.Sunrise);
  const ishraqDate=new Date(); const [sh,sm]=sunrise.split(":").map(Number); ishraqDate.setHours(sh,sm+15,0,0);
  const ishraq=ishraqDate.toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"});
  $("calculatedTimes").innerHTML=["Fajr","Sunrise","Ishraq","Dhuhr","Asr","Maghrib","Isha"].map(n=>{
    const v=n==="Ishraq"?ishraq:n==="Sunrise"?sunrise:prayerTimes[n];
    return `<div class="countrow"><span>${n}</span><b>${v||"--:--"}</b></div>`;
  }).join("");
  $("autoStatus").textContent=`Times calculated for ${label}. Ishraq shown approximately 15 minutes after sunrise.`;
  // Approximate beginning of the final third of the night: 2/3 of Maghrib-to-next-Fajr interval.
  const mag= new Date(), faj= new Date();
  const [mh,mm]=prayerTimes.Maghrib.split(":").map(Number), [fh,fm]=prayerTimes.Fajr.split(":").map(Number);
  mag.setHours(mh,mm,0,0); faj.setHours(fh,fm,0,0); if(faj<=mag)faj.setDate(faj.getDate()+1);
  const lastThird=new Date(mag.getTime()+(faj-mag)*2/3);
  $("tahajjudStatus").textContent=`Approximate last third of night starts: ${lastThird.toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"})}. Confirm with your local mosque.`;
  tick();
}
async function getTimes(lat,lon,label){
  $("autoStatus").textContent="Calculating prayer times…";
  try{
    const method=$("calcMethod").value||"3";
    const res=await fetch(`https://api.aladhan.com/v1/timings?latitude=${lat}&longitude=${lon}&method=${method}`);
    const json=await res.json(); if(json.code!==200)throw new Error("Prayer time service unavailable");
    displayCalculated(json.data,label);
    put("savedCoordinates",{lat,lon,label});
  }catch(e){$("autoStatus").textContent="Could not calculate times. Check internet and try again.";}
}
$("useLocation").onclick=()=>{
  if(!navigator.geolocation){$("autoStatus").textContent="Location is not supported by this browser.";return;}
  navigator.geolocation.getCurrentPosition(pos=>getTimes(pos.coords.latitude,pos.coords.longitude,"your location"),()=>{$("autoStatus").textContent="Location permission denied. Enter city and country instead."},{enableHighAccuracy:true,timeout:15000});
};
$("findCity").onclick=async()=>{
  const city=$("cityName").value.trim(),country=$("countryName").value.trim();
  if(!city||!country){$("autoStatus").textContent="Please enter both city and country.";return;}
  try{const r=await fetch("https://nominatim.openstreetmap.org/search?format=json&limit=1&q="+encodeURIComponent(city+", "+country));const a=await r.json();if(!a.length)throw new Error("City not found");getTimes(a[0].lat,a[0].lon,city+", "+country);}
  catch(e){$("autoStatus").textContent="Could not find city. Check spelling and internet.";}
};
$("calcMethod").onchange=()=>{const c=get("savedCoordinates",null);if(c)getTimes(c.lat,c.lon,c.label);};
const savedCoords=get("savedCoordinates",null);
if(savedCoords)getTimes(savedCoords.lat,savedCoords.lon,savedCoords.label);

if("serviceWorker" in navigator)window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js"));
