MUSLIM LIFE - ANDROID STUDIO PROJECT

यह ZIP अभी तैयार Android Studio source project है, APK नहीं।

APK बनाने के लिए:
1. कंप्यूटर में Android Studio इंस्टॉल करें।
2. इस ZIP को Extract करें।
3. Android Studio > Open > extracted Muslim Life project folder चुनें।
4. Gradle sync पूरा होने दें और Android SDK Platform 35 इंस्टॉल करें।
5. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
6. APK app/build/outputs/apk/debug/app-debug.apk में मिलेगा।

ध्यान दें:
- यह मौजूदा Muslim Life PWA को Android WebView में चलाता है।
- Location अनुमति Android से मांगी जाती है।
- Adhan/Reminder के background में विश्वसनीय बजने की गारंटी नहीं है।
- Prayer/Ishraq/Tahajjud समय अनुमानित हो सकते हैं; स्थानीय मस्जिद से पुष्टि करें।
- Play Store पर डालने से पहले release signing, privacy policy, testing और target SDK review जरूरी है।
